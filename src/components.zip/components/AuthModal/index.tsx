"use client";
import React, { useContext, useState } from "react";
import { Context } from "@/context";

const BACKEND_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

interface AuthModalProps {
  onClose?: () => void;
}

type Tab = "login" | "register";

export default function AuthModal({ onClose }: AuthModalProps) {
  const { login } = useContext(Context);
  const [tab, setTab] = useState<Tab>("login");

  // Login fields
  const [loginIdentifier, setLoginIdentifier] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [loginLoading, setLoginLoading] = useState(false);

  // Register fields
  const [regUsername, setRegUsername] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regError, setRegError] = useState("");
  const [regLoading, setRegLoading] = useState(false);
  const [regSuccess, setRegSuccess] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginIdentifier.trim() || !loginPassword.trim()) {
      setLoginError("Please fill in all fields.");
      return;
    }
    setLoginLoading(true);
    setLoginError("");
    try {
      await login(loginIdentifier.trim(), loginPassword);
      onClose?.();
    } catch (err: any) {
      setLoginError(err?.message || "Login failed. Check your credentials.");
    } finally {
      setLoginLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regUsername.trim() || !regEmail.trim() || !regPassword.trim()) {
      setRegError("Please fill in all fields.");
      return;
    }
    if (regPassword.length < 8) {
      setRegError("Password must be at least 8 characters.");
      return;
    }
    setRegLoading(true);
    setRegError("");
    try {
      const res = await fetch(`${BACKEND_URL}/api/v1/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: regUsername.trim(),
          email: regEmail.trim(),
          password: regPassword,
        }),
      });
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body?.data?.message || body?.message || "Registration failed");
      }
      setRegSuccess(true);
      // Auto-login after registration
      await login(regUsername.trim(), regPassword);
      onClose?.();
    } catch (err: any) {
      setRegError(err?.message || "Registration failed.");
    } finally {
      setRegLoading(false);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.75)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 9999,
      }}
    >
      <div
        style={{
          background: "#1a1d2e",
          borderRadius: "12px",
          width: "100%",
          maxWidth: "400px",
          padding: "32px 28px",
          boxShadow: "0 8px 40px rgba(0,0,0,0.6)",
          color: "#fff",
          fontFamily: "inherit",
        }}
      >
        {/* Logo / Title */}
        <div style={{ textAlign: "center", marginBottom: "24px" }}>
          <h2 style={{ margin: 0, fontSize: "22px", fontWeight: 700, color: "#f39c12" }}>
            ✈ Aviator
          </h2>
          <p style={{ margin: "6px 0 0", color: "#9097a8", fontSize: "13px" }}>
            {tab === "login" ? "Sign in to your account" : "Create a new account"}
          </p>
        </div>

        {/* Tab switcher */}
        <div
          style={{
            display: "flex",
            background: "#12141f",
            borderRadius: "8px",
            marginBottom: "24px",
            overflow: "hidden",
          }}
        >
          {(["login", "register"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              style={{
                flex: 1,
                padding: "10px",
                border: "none",
                cursor: "pointer",
                background: tab === t ? "#f39c12" : "transparent",
                color: tab === t ? "#000" : "#9097a8",
                fontWeight: tab === t ? 700 : 400,
                fontSize: "14px",
                transition: "all 0.2s",
                borderRadius: "8px",
              }}
            >
              {t === "login" ? "Sign In" : "Register"}
            </button>
          ))}
        </div>

        {/* Login form */}
        {tab === "login" && (
          <form onSubmit={handleLogin}>
            <div style={{ marginBottom: "16px" }}>
              <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", color: "#9097a8" }}>
                Username or Email
              </label>
              <input
                type="text"
                value={loginIdentifier}
                onChange={(e) => setLoginIdentifier(e.target.value)}
                placeholder="Enter username or email"
                autoComplete="username"
                style={inputStyle}
              />
            </div>
            <div style={{ marginBottom: "16px" }}>
              <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", color: "#9097a8" }}>
                Password
              </label>
              <input
                type="password"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="Enter password"
                autoComplete="current-password"
                style={inputStyle}
              />
            </div>
            {loginError && (
              <div style={{ color: "#e74c3c", fontSize: "13px", marginBottom: "12px" }}>
                {loginError}
              </div>
            )}
            <button
              type="submit"
              disabled={loginLoading}
              style={submitBtnStyle(loginLoading)}
            >
              {loginLoading ? "Signing in..." : "Sign In"}
            </button>
          </form>
        )}

        {/* Register form */}
        {tab === "register" && (
          <form onSubmit={handleRegister}>
            <div style={{ marginBottom: "16px" }}>
              <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", color: "#9097a8" }}>
                Username
              </label>
              <input
                type="text"
                value={regUsername}
                onChange={(e) => setRegUsername(e.target.value)}
                placeholder="Choose a username"
                autoComplete="username"
                style={inputStyle}
              />
            </div>
            <div style={{ marginBottom: "16px" }}>
              <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", color: "#9097a8" }}>
                Email
              </label>
              <input
                type="email"
                value={regEmail}
                onChange={(e) => setRegEmail(e.target.value)}
                placeholder="Enter your email"
                autoComplete="email"
                style={inputStyle}
              />
            </div>
            <div style={{ marginBottom: "16px" }}>
              <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", color: "#9097a8" }}>
                Password
              </label>
              <input
                type="password"
                value={regPassword}
                onChange={(e) => setRegPassword(e.target.value)}
                placeholder="Min 6 characters"
                autoComplete="new-password"
                style={inputStyle}
              />
            </div>
            {regError && (
              <div style={{ color: "#e74c3c", fontSize: "13px", marginBottom: "12px" }}>
                {regError}
              </div>
            )}
            {regSuccess && (
              <div style={{ color: "#27ae60", fontSize: "13px", marginBottom: "12px" }}>
                Account created! Logging in...
              </div>
            )}
            <button
              type="submit"
              disabled={regLoading}
              style={submitBtnStyle(regLoading)}
            >
              {regLoading ? "Creating account..." : "Create Account"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "10px 12px",
  background: "#12141f",
  border: "1px solid #2c3150",
  borderRadius: "8px",
  color: "#fff",
  fontSize: "14px",
  outline: "none",
  boxSizing: "border-box",
};

const submitBtnStyle = (disabled: boolean): React.CSSProperties => ({
  width: "100%",
  padding: "12px",
  background: disabled ? "#6b5a2a" : "#f39c12",
  color: disabled ? "#aaa" : "#000",
  border: "none",
  borderRadius: "8px",
  fontSize: "15px",
  fontWeight: 700,
  cursor: disabled ? "not-allowed" : "pointer",
  transition: "background 0.2s",
});
