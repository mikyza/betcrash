"use client";
import React, { useContext, useState } from "react";
import { Context } from "@/context";
import toast from "react-hot-toast";

const BACKEND_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

// Pre-set deposit amounts
const QUICK_AMOUNTS = [100, 200, 500, 1000, 2000, 5000];

interface DepositModalProps {
  onClose: () => void;
}

declare global {
  interface Window {
    Razorpay: any;
  }
}

function loadRazorpayScript(): Promise<boolean> {
  return new Promise((resolve) => {
    if (typeof window === "undefined") return resolve(false);
    if ((window as any).Razorpay) return resolve(true);
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

export default function DepositModal({ onClose }: DepositModalProps) {
  const { userInfo, updateUserInfo } = useContext(Context);
  const [amount, setAmount] = useState<string>("500");
  const [loading, setLoading] = useState(false);

  const handleDeposit = async () => {
    const numAmount = Number(amount);
    if (!numAmount || numAmount < 100) {
      toast.error("Minimum deposit is ₹100");
      return;
    }

    const token = typeof window !== "undefined" ? localStorage.getItem("aviator_token") : "";
    if (!token) {
      toast.error("Please login first");
      return;
    }

    setLoading(true);
    try {
      // 1. Create order on backend
      const res = await fetch(`${BACKEND_URL}/api/v1/payments/deposit`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ amount: numAmount, provider: "razorpay" }),
      });

      const body = await res.json();
      if (!res.ok) throw new Error(body?.data?.message || body?.message || "Order creation failed");

      const { orderId, amount: orderAmount, currency, keyId, transactionId } = body.data;

      // 2. Load Razorpay script
      const loaded = await loadRazorpayScript();
      if (!loaded) throw new Error("Failed to load payment gateway");

      // 3. Open Razorpay checkout
      const rzp = new window.Razorpay({
        key: keyId,
        amount: orderAmount, // already in paise
        currency: currency || "INR",
        order_id: orderId,
        name: "Aviator Game",
        description: "Wallet Deposit",
        image: "/images/logo.svg",
        prefill: {
          name: userInfo.userName,
          email: "",
          contact: "",
        },
        theme: { color: "#f39c12" },
        modal: {
          ondismiss: () => {
            setLoading(false);
          },
        },
        handler: async (response: {
          razorpay_payment_id: string;
          razorpay_order_id: string;
          razorpay_signature: string;
        }) => {
          // 4. Verify on backend
          try {
            const verifyRes = await fetch(`${BACKEND_URL}/api/v1/payments/razorpay/verify`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
              },
              body: JSON.stringify({
                orderId: response.razorpay_order_id,
                paymentId: response.razorpay_payment_id,
                signature: response.razorpay_signature,
              }),
            });
            const verifyBody = await verifyRes.json();
            if (!verifyRes.ok) throw new Error(verifyBody?.message || "Verification failed");

            // 5. Update local balance
            const newBalance = verifyBody?.data?.balance ?? userInfo.balance + numAmount;
            updateUserInfo({ ...userInfo, balance: newBalance });
            toast.success(`₹${numAmount.toLocaleString()} added to wallet!`);
            onClose();
          } catch (err: any) {
            toast.error(err?.message || "Payment verification failed. Contact support.");
          } finally {
            setLoading(false);
          }
        },
      });

      rzp.on("payment.failed", (response: any) => {
        toast.error(`Payment failed: ${response.error?.description || "Unknown error"}`);
        setLoading(false);
      });

      rzp.open();
    } catch (err: any) {
      toast.error(err?.message || "Could not initiate deposit");
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.75)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 9998,
      }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        style={{
          background: "#1a1d2e",
          borderRadius: "12px",
          width: "100%",
          maxWidth: "420px",
          padding: "28px",
          boxShadow: "0 8px 40px rgba(0,0,0,0.6)",
          color: "#fff",
        }}
      >
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
          <h3 style={{ margin: 0, fontSize: "18px", fontWeight: 700, color: "#f39c12" }}>
            Add Money
          </h3>
          <button
            onClick={onClose}
            style={{
              background: "none", border: "none", color: "#9097a8",
              fontSize: "22px", cursor: "pointer", lineHeight: 1,
            }}
          >
            ×
          </button>
        </div>

        {/* Current Balance */}
        <div
          style={{
            background: "#12141f", borderRadius: "8px", padding: "12px 16px",
            marginBottom: "20px", display: "flex", justifyContent: "space-between",
          }}
        >
          <span style={{ color: "#9097a8", fontSize: "13px" }}>Current Balance</span>
          <span style={{ fontWeight: 700, color: "#f39c12" }}>
            ₹{Number(userInfo.balance).toFixed(2)}
          </span>
        </div>

        {/* Quick Select Amounts */}
        <div style={{ marginBottom: "16px" }}>
          <label style={{ display: "block", marginBottom: "10px", fontSize: "13px", color: "#9097a8" }}>
            Quick Select
          </label>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "8px" }}>
            {QUICK_AMOUNTS.map((amt) => (
              <button
                key={amt}
                onClick={() => setAmount(String(amt))}
                style={{
                  padding: "10px 6px",
                  background: amount === String(amt) ? "#f39c12" : "#12141f",
                  color: amount === String(amt) ? "#000" : "#9097a8",
                  border: `1px solid ${amount === String(amt) ? "#f39c12" : "#2c3150"}`,
                  borderRadius: "8px",
                  cursor: "pointer",
                  fontSize: "14px",
                  fontWeight: amount === String(amt) ? 700 : 400,
                  transition: "all 0.15s",
                }}
              >
                ₹{amt.toLocaleString()}
              </button>
            ))}
          </div>
        </div>

        {/* Custom amount */}
        <div style={{ marginBottom: "20px" }}>
          <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", color: "#9097a8" }}>
            Or enter amount (Min ₹100)
          </label>
          <input
            type="number"
            value={amount}
            min={100}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="Enter amount"
            style={{
              width: "100%",
              padding: "10px 12px",
              background: "#12141f",
              border: "1px solid #2c3150",
              borderRadius: "8px",
              color: "#fff",
              fontSize: "16px",
              fontWeight: 600,
              outline: "none",
              boxSizing: "border-box",
            }}
          />
        </div>

        {/* Pay Button */}
        <button
          onClick={handleDeposit}
          disabled={loading}
          style={{
            width: "100%",
            padding: "14px",
            background: loading ? "#6b5a2a" : "#f39c12",
            color: loading ? "#aaa" : "#000",
            border: "none",
            borderRadius: "8px",
            fontSize: "16px",
            fontWeight: 700,
            cursor: loading ? "not-allowed" : "pointer",
            transition: "background 0.2s",
          }}
        >
          {loading ? "Processing..." : `Pay ₹${Number(amount || 0).toLocaleString()} via Razorpay`}
        </button>

        {/* Security note */}
        <p style={{ textAlign: "center", color: "#9097a8", fontSize: "12px", marginTop: "12px", marginBottom: 0 }}>
          🔒 Secured by Razorpay · UPI, Cards, Net Banking accepted
        </p>
      </div>
    </div>
  );
}
